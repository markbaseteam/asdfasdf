# Prologue
It's the first day at [[The Academy]]. [[Gil]] is very excited. In fact, he was so excited that he left an hour early. Just so that he could mix in with people already there and make new friends. Unfortunately, fate had other plans for him. 

"Kid! Look out!"

A man yelled while to the child crossing the street. That child is [[Gil]]. [[Gil]] looked over and saw a man riding a flaming horse that is empowered with acceleration magic. Normally, using ether to reinforce himself to the point to take a hit is simple. Any graduate of a magic academy could do it. However, [[Gil]] simply lacked the reaction time. The horse barreled straight at him, and he was sent flying. The flaming horse continued into the distance. [[Gil]] was slammed into a wall, breathing heavily but that only made his condition worse. During the impact broke many ribs. Trying to take a deep breath made his lungs expand against the rib and punctured it. 

"Come on, guys! Help me get him to the hospital!" A nearby pedestrian said.

 With magic they lifted his body and carried it to the nearest hospital. People who noticed also carried helped carried him. [[Gil]] reached the hospital after a few minutes but he already lost consciousness a few seconds after he punctured his lung. He remained unconscious for a full day. Before he finally woke up. 

"Uwahh!" [[Gil]] screamed, as he woke up. He shot up from the bed. Pain spread throughout his body as he winced in pain. [[Gil]]'s only family, his sister was sleep on a nearby chair. She woke up because of all the noise [[Gil]] made. She rubbed her tired eyes, and shot towards him when she saw he is awake. 

"[[Gil]]!" She exclaimed as she hugged him tight. Gil let out a pained groan. She let go immediately not wanting to accidentally hurt him anymore. "What happened?" [[Gil]] asked groggily. His vision turned from fuzzy to clear in a few seconds. The fuzzy outline of a person is now made clear to be his sister. He also saw the various tubs connected to him.

"It's anesthesia." His sister, [[Aurora]] explained. "It put your to sleep and dulled your pain. It has been a full day since the accident." [[Gil]] nodded lightly. As he started to recall what happened to him. *I was on my way to school, then this horse came out of nowhere.* It took a second to realize what he missed out on.

"[[The Academy]]!" He exclaimed. "I missed it!" His voice full of regret. Gil isn't the most social person in middle school. Gil wasn't a completely anti social person. He has friends, but, it felt like something wasn't there. He felt that that something would make all the difference.

"You did. I know how much it meant to you. You were so excited the day before. You kept telling me all about it at dinner." 

[[Gil]] was so excited that he actually couldn't sleep for an hour. "Great. Just great." [[Gil]] let out a long sigh. The reason he's so excited is because no one knew him. He could have a personality overhaul and no one would find it odd. His plan is to incrementally change himself to be a more social person.

"So, when are they giving me some vampire blood?" He asked. 

Vampire blood, or the blood of any undead can be used to heal the wounds of anything that ingested it. The reason vampire blood is used more commonly is because vampires are one of the few undead species that have intelligence that can be fostered like a human. Other undead creatures like Draugr or Wisps are deranged creatures, born from the corrupted souls of the departed. They will attack the living on sight. Making it a lot more difficult for people to harvest their blood. Because of this doctors would go to various vampire villages to request for a blood donation. A vampire's healing ability actually makes this incredibly difficult as something as light as a cut would heal and seal up the wound immediately. Doctors have to literally poison them with Echoflame to inhibit their regenerative abilities.

"They won't. When the rib punctured your lung, if they gave you vampire blood your lung would heal around your rib. That has to be avoided at all costs. You are to remain in here for 3 weeks, until your body's natural healing heals you to the point where that risk is no longer present. Then and only then are you allowed to drink vampire blood." [[Aurora]] said in a stern voice. [[Gil]] knew he was in no position to reject in his present condition, and he also couldn't go against his sister when all she is is just concerned.

Two weeks passed and the healing has gone swimmingly, the owner of the flaming horse stopped by two days after [[Gil]] regained consciousness and frantically apologized. He also paid for all the costs upfront and to get in touch with him if there was anything else that is needed. [[Gil]] is allowed in the public recreational area where hospital staff are constantly watching the patients. They've been talking for the past two weeks and they got to know each other. 

[[Gil]] had worked hard to come up with topics of conversation once the usual stuff was finished, those being "Why did you get here?", "How long do you need to stay?", "Say, how did your family receive this news?" Which is really low hanging fruit.  [[Gil]] also met members of other species. Most nurses are vampires, as vampire blood can heal any wound barring special exceptions like himself. So he's made friends with the staff. There are some species that do not need treatment. Such as vampires or werewolves. Vampires can heal their lost limbs can be healed completely in days, werewolves' don't posses such potent regenerative abilities, however. 

[[Gil]] chatted with a few people around the public and before he noticed it it was lunch time. Visiting hours are from 12:00 to 20:00, the mornings are used by staff members to do checkups and other maintenance and requires the area to be cleared of civilian and patients. [[Gil]] headed towards his room and started reading a book he picked up from the library. [[Aurora]] arrived after half an hour of reading. They would have lunch together and she would stay by his side until 20:00. 

"It's so good!" He said as he stuffed himself full of rice.

[[Gil]] always loved [[Aurora]]'s cooking, she's a fantastic cook. After the death of their parents she had no choice but to learn how to cook or let [[Gil]] starve. Something she could never allow.

"Thanks." [[Aurora]] accepted the complement. They made idle chit chat as they ate.
"Say, when you getting a boyfriend." [[Gil]] asked. 
"When I get one." [[Aurora]] replied snarkily. 
"I hear that one all the time." [[Gil]] quipped. 
"When you do get one make sure I get a good look at him. No trash is going to touch this sister of mine." [[Gil]] said adamantly. 
"Please." [[Aurora]] dismissed [[Gil]]. 
Then someone knocked on the door and a nurse appeared, "Hello, again. This is yours." He said as he handed the package over to [[Aurora]]. 
"I'm curious, what is it?" The nurse asked, "Oh, it's just class materials. I do not want to be very behind on work. The catch up will be difficult if I start when I get discharged."
The nurse nodded approvingly, "Well, good luck!" He said before leaving. "So, you'll be able to get out next week. What are you expecting?" [[Aurora]] asked. "I'm expecting a fun classroom." 
