# Oa, Ruby and Luna
The classroom is rowdy and everyone is discussing the latest exam, the one where everyone ventured into the Eidetic Woods. Not their own results, but, of what happened to the new guys. The new guys are of course, Gil, Luna, Ruby, Totsuka and Terul. After the exam no one has seen them since. They've just disappeared for 3 days. Other than the victims themselves, Ursa and Axel. No one knows what truly happened. But, there is a chance that someone saw the whole fight but is keeping quite. Which is the natural reaction. *I wish they would stop theorizing.* The blue haired boy spaced out and then quickly shook his head. The blue haired boy continued to day dream.

"Still, what happened to them?" His friend said. "Hey." He called out, but the blue haired boy didn't reply. "Hey." He repeated once more. "Oa! You home in there?" The boy who is trying to get the blue haired boy, Oa's attention is his friend, Kai.

"What? Can't I go thinking?" 
"You've been thinking an awful lot don't you? But, it did net us maximum scores for the exam!" Kai said as he laughed. Oa's strategy is an impressive one. He noticed that Ursa never mentioned anything about the tablet being used for grading. Even how the leader is decided isn't dependent on returning the tablet. Because of this he told his teammates to decide to do nothing. Instead of being launched off into the Eidetic Woods, they stepped off it at the last second and simply laid on the ground. Naturally, Ursa questioned them for their decision. Impressed with Oa's reasoning gave his team maximum scores a few minutes into the exam.
"Yeah, that was awesome!" A fellow teammate, Antha supported Kai's statement.
"I always get so impressed when people do stuff like that. I'm one lucky guy to team up with you!" The final team member, Nero said.

"Calm down." Ursa said as she slammed her fist against the blackboard. "I can hear you talking about what happened to the newcomers, well, stop. Allow me to put an end to it. They are all missing from class is due to personal reasons."
*All five of them gone due to personal reason at the same time? It makes sense for the siblings, but, Luna, Gil and Terul too? That's a bit of a stretch.* Oa thought. "Now, they won't be joining us for a while. But, that doesn't concern you. Let's begin class." With that the class turned silent. Ursa opened her textbook and started writing on the blackboard. Starting the first class of the day.

Meanwhile in the pocket dimension Axel created to let the students rest, Ruby and Luna are talking. "When are they going to wake up?" Ruby said her voice full of concern. As she looked over at Gil and Totsuka. "No clue... It's been 3 days. I just woke up just two days ago." The pair recalled what happened to Gil and Totsuka. Gil was turned into a human bullet, if it wasn't for Ruby he would have a tree coming out of his chest. Without Axel, Totsuka would be dead by now. Ruby is eternally grateful to him for that. 

"I still have the fight with Terul in my head. It's on repeat for some reason, I can't get it out of my head."
"Mhm." Luna agreed, "I can't either. I guess it can't be helped. I've never fought other people in a real fight before. That was a fight where someone was really going to die."
"Look at you! You managed to stay level headed the whole time and trapped Terul." Ruby said in her usual cheerful tone.
"It didn't last long. He wasn't even using all of his strength. He escaped really easily. On top of that did you know how stressed and nervous I was? I was always told to never show fear in battle. I was so surprised I managed to stop myself from just collapsing onto the ground."
"Either way, it helped a lot. It bought enough time for Axel to come and save us." Ruby sighed, "I need to get stronger, so, this doesn't happen again." Ruby looked at Totsuka, who still hasn't woken up yet. "I need to protect him!" Ruby's eyes burned with determination.
"We all need to get stronger. So, that we can protect each other. We've just met each other, but, the fact that you went out of your way to save Gil by expending all your ether is commendable. Makes me feel a little ashamed for not doing as much."
"Don't say that." Ruby placed a hand on Luna's shoulder's, "You did a lot. Trapping Terul was nothing short of amazing. I mean, it lead to you getting smashed into the ground. We both did plenty." Luna nodded and thanked Ruby. "I have my parents to thank for that. I used to only look out for myself, until I was accepted into Totsuka's family. They told me the powerful are grouped into two types. The ones who put their strength in service of others, and those to put it in service for themselves."
"I guess that's why so many people love Axel." Axel one of the three Greats. He did battle along with his other friends, the other two Greats during the Evara Crisis. Saving the world. That battle would be written down in the annals of history, never forgotten. 

Then Axel appeared, it appears to be the end of the day. As Axel has always showed up around the same time each day. "Are you both ready?" He asked and the pair nodded. "Very well, let's begin." But instead of being taught the class that they missed, instead the pair found themselves in a separate space.

"Where are we?" Ruby said, she noticed that Axel is standing on the far end of the space. Which felt weird since she also knew that Axel's pocket dimension is infinitely large. So, it's more accurate to say he stood far away.
"You wanted to get stronger to protect your brother, right?" Ruby was a little shocked that Axel knew this, but, when she thought about it it made sense that Axel could figure it out. "Not just him either, isn't it? You want to protect all your friends. Don't you?" Axel looked at Ruby then Luna. Ruby responded with a determined, "Yes." Luna didn't respond, but, that look in her eye was all the confirmation Axel needed.
"Good. Then, don't hold back! Come at me!" Axel commanded the pair, as he thrust his fist forward. Encouraging the two to come at him.
"Sir!" The two said in unison. As Ruby manifested her flaming sword and charged at Axel, Luna drew back on her bow.

"So, do you understand?" Ursa asked the class as a whole. Today's topic is chemistry. Specifically reactions. Not every class is about magic. Axel made sure that magic isn't the only subject taught. History, physics, chemistry and so on. Antha is lying his head on his desk, if you were to look close enough you could see spirals in his eyes and steam coming off his head. Nero wasn't much better either, as, he took notes so he was able to keep up. Antha didn't do anything. Kai and Oa were both fine though. 

Kai raised his hand, Ursa was cleaning the board but stopped to respond.
"Yes?"
"Miss Ursa, have you ever applied any of these little tricks before? It would seem to be pretty difficult to manage so many things at once."
"Yes, of course." Ursa said bluntly, "It's easy for me because of the years I've had to practice. It's important to understand these rules of nature. It gives you an edge over your opponent. Even if only a slight one every bit in a real fight counts. But for now, start small. At least notice an option to use what you've learnt today." 

Ursa turned her back on Kai and continued to clean the board ending the conversation.
"Well, that makes sense." Kai said. "So, today's the day we get to enter in a club. What are you thinking of joining?"

During Gil's three week absence the first years have already gotten introduced to the various clubs that are available. Not all of them were in the hall as there were simply too many clubs. Which is why today, clubs that didn't get a chance to promote themselves will do so today. There are a lot of clubs. There are ones that suit everyone's interests. From ether circuitry all the way to singing. Unlike other schools that focus on combat the reason [[The Academy]] is such an influential school is because of Axel's innovations. He leaned into the social aspect of school and created clubs. He also included a syllabus that isn't just pure combat training. Giving everyone a chance to relax and learn at the same time. There are separate schools that provide education on topics such as physics and the like. [[The Academy]] is the first school to provide education on combat training and academic training in one package. Which has made it incredibly popular. Axel is one of the most inventive people as well. Introducing many technologies over the years such as the television set among other things.

"I'm thinking of joining the culinary club. I'm interested in cooking, and I find it a pleasure to enjoy food with others. Great way of bonding too." Nero said. Kai looked at Antha, which meant it's his turn to answer.
"Simple, combat club. I like fighting." That's all Antha said.
"Well, as for me. I'd love to join the book club. I've gotten into reading lately and whether it be about fiction or non-fiction as long as it's interesting I'll give it a read. Besides, it feels like it has made me smarter." Kai answered.
"Well, it could have. Reading things will slowly help you accumulate knowledge. That's a given."
"Yeah, what Oa said!" Antha supported his statement.
"What about you?" Nero asked Oa.
"Not sure, might not even join one. None of them particularly interest me. I'm happy just going home and doing my own thing." Oa doesn't have expression interest in anything particular. Sure, when he likes something he'll dive into it. There was a point in time when he was really into music, so, he spent a lot of time on it. But, then the music phase passed and he stopped.
"Isn't that kind of boring?" Oa shrugged at Antha's question, "I don't know. It's fine to me. I'm not bored anyways." 
"Well, he's not by it bothered. Everyone's different. Now lay off him" Nero said.
"I'm not laying into him in the first place!" Antha countered.
"Guys, relax. Kai, don't you need to go to the club classroom and register?" Realizing that Oa wanted this conversation to end, Kai nodded.
"That I do, see you guys tomorrow." Kai left the room after saying goodbye to his friends. The others soon followed suit. Oa let out a sigh after saying goodbye and splitting off from the group. "Maybe I will checkout the clubs after all." He said to himself as he headed towards the hall. It didn't take long for the group to reach the hall. Club booths were stationed in a regular pattern. A group of 4 booths followed by some space then another group of 4 booths. Even before reaching the hall he could hear various voices promoting their own club. The words "CLUB FAIR" were floating at the center of the main hall. *That's pretty clear considering what's going on here.* Oa thought it was redundant.

"Join us! We are the dancer's club!" A girl shouted from atop a pyramid formed by other club members. She did a backflip in place and instead of landing on her feet, she instead put her arm out and supported herself with it. Her legs now in the air as she looked on everyone form above. Everyone said in unison, "It's fun! Don't miss out! We'd love to have you!" *Now that's advertisement.* Oa thought. 

Being flashy will certainly catch people's attention. Oa continued to walk around he saw the gamer's club. Where the latest games were put on display. The latest board game designed by famous game designer, Takuito, Infinite Labrynth's board is put out. A club member inviting various passerby to join him for a game whenever someone got close enough. Oa didn't stick around to find out if anyone joined him for a game though. The hall is huge it would take a while to see all the clubs. Oa continued walking, and sometimes stopping to observe activities of other clubs. He even asked for some details for the Inferno ball club that peaked his interest. 

Oa sighed again, "Nothing much I like. Was it a waste of time?" Oa already spent half an hour walking around, "There are a few more. I might as well take a look."

"Man, this is fun." Axel said with a smile.
"Easy... for you to say!" Ruby squeezed out with bated breathe.
She didn't know if Luna said anything, she was just too far away. Then, "He threw us around like ragdolls." Her found was suddenly beside Ruby. Ruby wasn't sure if Axel teleported her to them. Or the two of them to her, but, it didn't matter.
"Oh, guess I'm here now." Luna said, surprised.
"Or am I here now?" Ruby wasn't surprised because one of the tricks Axel pulled was when she got close enough was to teleport her five feet away. When she got close again he would keep doing the same thing. Which was incredibly annoying.
"That wasn't even a fight! You were just messing with us!"
"There is a reason I fought you like that you know?"
"Oh yeah?" Ruby questioned.
"Yeah. So, that you can use this more." Axel pointed at his head.
"My skull? I guess I do want to use my skull and smash it into your head right now." 
"That's not what I meant." 
"I know, I know." Ruby and Luna both got up. "You wanted us to analyze for a way to defeat your even when you use these tricks right?" Axel nodded. "Not everyone fights head on like Terul, so, we need to be smart not just strong." Axel nodded again. *Did Ruby just glow for a second?*
"Very good, seems like you got it. Well, I'm gonna have some more fun throwing you around tomorrow." Ruby and Luna were both teleported back to the recovery pocket dimension and Axel left.
"He didn't even bother sugarcoating it."
"Yeah, he literally said 'throwing us around'."
"Sup, guys. Where'd you come from?" The pair recognized Gil's voice and saw him sitting on the couching watch some television. "You're awake!" Ruby hugged Gil immediately, which was really surprising. He wasn't used to a girl being this friendly with him before, so, he blushed a little. "You had us worried for a second!" Ruby then hit him on the shoulder. What's more surprising as that Ruby showed genuine concern. Considering they've met not too long ago.
"Don't worry, I'm a tough nut to crack. Anyways where are we?"
"It's Sir Axel's pocket dimension."
"Aren't you sweaty, Gil?" Luna asked.
"Why would I be sweaty?"
"Well, I mean. Me and Ruby both were working pretty hard and sweat a lot." Gil took a look at Luna and saw that her clothes is drenched is sweat. 
"Well, I just use fire magic to raise my body temperature until it's hot enough to kill all sorts of bacteria. Oh if you didn't know bacteria is what makes you smell after you sweat, viruses and other stuff." Ruby explained. *So that's why she smells so good.* Gil thought. He immediately shook his head to clear those thoughts.
"So, do you need to take bath or shower?"
"Nope!" Ruby extended her hand and gave Luna a thumbs up. "I don't need to brush my teeth either!" Then moved her hands close to her face and gave a peace sign.
"Is that why you glowed when talking to Sir Axel?" Luna asked. 
"Yep."
"So, what exactly happened? I remember getting hit and that's it." Ruby and Luna then went ahead to explain what happened after Gil was knocked out.
"I see. He probably needed his heart for something important. Otherwise he wouldn't have slowed down."
"What would he need his heart for?"
"It could be for a lot of things. The heart of a hybrid is a very powerful magical item that be used to grant powerful attributes to items. Or it could be for a spell, a ritual, it could be any number of things. Given how rare hybrids are, he probably wanted to do something that requires a great deal of power. Either way, I can question him at anytime."
"Where is he anyways?" Ruby asked. 
"He's in another one of my pocket dimensions. One that isn't as accommodating." Axel teleported everyone to the pocket dimension where Terul is in. It's so dark that Ruby couldn't see anything. Luna made some light with light magic and had it follow them around.
"This is where you're keeping him?" Axel nodded. "As you can see, it's just a black box that goes out in all direction infinitely. Putting him in here and starving him of social interaction, food, water will make it easier to interrogate him. In order to break the man, one must first break his spirit." 
"Where is he, I can't see him." Luna said as she looked at her surroundings. "Oh, he's right there." Axel pointed to his feet. Ruby and Luna shifted their line of sight to where Axel pointed and saw Terul curled up into a ball. Lying on his side.
"Wait, we're above him? What are we standing on?" Ruby said in shock. Then she started to fall. Luna did too. It's as if they fell through the ground. Ruby has no idea what is happening. She was standing on something solid then the ground disappeared and she started falling. They both screamed as they were falling. Then they appeared back at Axel's side. With wind magic he levitated the both of them stopping them from falling. This obvious caught Terul's attention.

"You!" He said menacingly. Lightning covered his body and he moved incredibly quickly towards Axel. But Axel simply teleported him further away. "He won't be bothering us for a while. No you aren't standing on anything. I told you. This pocket dimension stretches in all directions infinitely. Including downwards." Ruby and Luna are both breathing heavily, catching their breathe. It went without saying sudden falling surprised them. 
"The reason you're able to stand is because you believed that there's ground beneath your feet. This is a prison of your own mind. This spell doesn't hurt you physically, it doesn't try to take off an arm. None of that. It traps you in your own mind. Because you *believed* that you weren't standing on anything you fell through."
"Then can I believe myself into getting out of here?" Axel laughed softly at Luna's statement, "No. You cannot." That soft laugh was what terrified the two of them the most. Axel doesn't just hurt you physically, he hurts you mentally too. 
Then the two of them were teleported out of the black box. They both involuntarily let out sighs that granted them relief. They found themselves surrounded by people talking. Ruby heard a girl shout, "Join us! We are the dancer's club!" A girl shouted from atop a pyramid made with other people.
"Where are we?" Ruby asked.
"Back at [[The Academy]]. School ended and I thought I'd give the both of you an opportunity to enjoy yourself. These are some clubs we have. Feel free to browse and join a club if you so wish to. Enjoy yourselves. If you need anything simply return to my office. In a few days time I can let you go back to class."
"What about Gil and my brother?" A natural question, "I'll let them go once I determine them to be in fit condition to do so. For now, just relax. Staying there all the time would constantly remind you that they're injured. So forget about it for just an hour or two, alright?" With that Axel disappeared, or more accurately teleported away.
"We might as well take a look." Luna said to Ruby. As she spotted a blue haired boy in the corner of her eye.

*Is that Ruby and Luna?* Oa spotted them nearby a rest area with some staff selling food. He walked up and once he got close enough.
"Ruby, Luna. Is that you?" Ruby recognized the boy who called out to him thanks to his striking blue hair. But, he didn't know his name.
"Are you from the same class as me?" Ruby asked. Oa nodded. Oa was dying to find out what happened to their team. It was too odd for them to *all* disappear for a few days.
"I'm sorry if this is a personal question, but, what did you guys do after the exam in the Woods?"

Naturally they are unable to speak of what happened. Axel did tell them very explicitly to not tell everyone that a student was assaulted by another. Not only would it bring panic to the student body, drawing other undead to the school. The information would eventually come to light to the public, making the situation even worse in a vicious cycle. They couldn't exactly hide their facial expressions without being suspicious either. So they had no choice but to let Oa read them.  ^c79ebb

"Oh, well. My parents called me and my brother back as we had an event with relatives." Ruby forced out. 

Oa already found this suspicious. Vampires place high value in a pure bloodline. A family of vampires that birthed a vampire-human hybrid along with adopting a human into the family. Would very easily lead to said family getting disowned or alienated by the vampire community they reside in. There are vampires that are opened minded. However, it is incredible rare. This tipped him off, and he decided to probe a little further. Although, he had a feeling that he shouldn't. But, he couldn't help himself. His curiosity got the better of him.

"I'd rather not talk about it. It was quite traumatic event." Luna simply stated the truth. Oa immediately felt guilty for even questioning her. But even so he continued investigating.
"Say, what about Gil, your brother and Terul. Do you know what became of them? The class is a little worried about Terul. We haven't seen him in a while." Oa carefully observed them to see if there were other clues. There wasn't any notable reactions when Gil's name or Totsuka was mentioned. However, when the word "Terul" was uttered. He felt some sort of pressure from Ruby. It felt like rage. Deciding that was enough that Terul probably had something to do with it and he felt like if he kept going something bad would happen. He ended the conversation with an apology.
"Sorry." He said awkwardly while scratching his head. "This is clearly personal. I really shouldn't have intruded. If you need anything, feel free to ask. I feel like I owe you this much." Providing his own form of compensation would be the best thing to do.
"It's fine. Don't worry about it." However, Ruby rejected it. Instead letting him off the hook. Oa internally breathed a sigh of relief. Then walked slightly quicker than usual.
"Well, see you in class." Ruby and Luna both waved him goodbye, and Oa waved back.
